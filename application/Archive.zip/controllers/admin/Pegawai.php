<?php
defined('BASEPATH') or exit('No direct script access allowed');
class pegawai extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('upload');
        if (!$this->session->userdata('user_id')) {
            // ALERT
            $alertStatus  = 'failed';
            $alertMessage = 'Anda tidak memiliki Hak Akses atau Session anda sudah habis';
            getAlert($alertStatus, $alertMessage);
            redirect('admin/dashboard');
        }
    }


    public function index()
    {
        $url = "https://upbuhaluoleo.test-web.my.id/api/getAccessToken?client_id=dr1v3-up6u&client_secret=98fpj-jpkLs-88G5f-9Wq1r";
        $get_url = file_get_contents($url);
        $token =  json_decode($get_url);
        if (!empty($token)) {
            $opts = [
                "http" => [
                    "method" => "GET",
                    "header" => "Access-Token: " . $token->access_token
                ]
            ];
            $context = stream_context_create($opts);
            //DATA
            $data['setting'] = getSetting();
            $data['title'] = 'pegawai';
            $url = "https://upbuhaluoleo.test-web.my.id/api/get_pegawai";
            $get_url = file_get_contents($url, false, $context);
            $data['pegawai'] = json_decode($get_url);
            // echo '<pre>';
            // print_r(($data['pegawai']));
            // echo '</pre>';
            // die;
            // TEMPLATE
            $view = "_backend/pegawai";
            $viewCategory = "all";
            renderTemplate($data, $view, $viewCategory);
        }
    }

    public function create()
    {
        csrfValidate();
        // if ($_FILES['foto_pegawai']['name'] != "") {
        //     $filename_1              = "pegawai-" . date('YmdHis');
        //     $config['upload_path']   = "./upload/pegawai/";
        //     $config['allowed_types'] = "jpg|png|jpeg";
        //     $config['overwrite']     = "true";
        //     $config['max_size']      = "0";
        //     $config['max_width']     = "10000";
        //     $config['max_height']    = "10000";
        //     $config['file_name']     = '' . $filename_1;
        //     $this->upload->initialize($config);
        //     if (!$this->upload->do_upload('foto_pegawai')) {

        //         // ALERT
        //         $alertStatus  = "failed";
        //         $alertMessage = $this->upload->display_errors();
        //         getAlert($alertStatus, $alertMessage);
        //     } else {
        //         $dat  = $this->upload->data();
        //         $data['foto_pegawai']      = $dat['file_name'];
        //     }
        // } else {
        //     $data['foto_pegawai']      = '';
        // }
        $data['id_pegawai']   = $this->input->post('id_pegawai');
        $data['nama_pegawai'] = $this->input->post('nama_pegawai');
        $this->m_pegawai->create($data);

        // ALERT
        $alertStatus  = "success";
        $alertMessage = "Berhasil menambah data pegawai dengan name = " . $data['nama_pegawai'];
        getAlert($alertStatus, $alertMessage);


        redirect('admin/pegawai');
    }


    public function update()
    {
        csrfValidate();
        // if ($_FILES['foto_pegawai']['name'] != "") {
        //     $filename_1              = "pegawai-" . date('YmdHis');
        //     $config['upload_path']   = "./upload/pegawai/";
        //     $config['allowed_types'] = "jpg|png|jpeg";
        //     $config['overwrite']     = "true";
        //     $config['max_size']      = "0";
        //     $config['max_width']     = "10000";
        //     $config['max_height']    = "10000";
        //     $config['file_name']     = '' . $filename_1;
        //     $this->upload->initialize($config);
        //     if (!$this->upload->do_upload('foto_pegawai')) {

        //         // ALERT
        //         $alertStatus  = "failed";
        //         $alertMessage = $this->upload->display_errors();
        //         getAlert($alertStatus, $alertMessage);
        //     } else {
        //         $dat  = $this->upload->data();
        //         $data['foto_pegawai']      = $dat['file_name'];
        //     }
        // }

        // POST
        $data['id_pegawai'] = $this->input->post('id_pegawai');
        $data['nama_pegawai'] = $this->input->post('nama_pegawai');
        $this->m_pegawai->update($data);

        // ALERT
        $alertStatus  = "success";
        $alertMessage = "Berhasil mengubah data pegawai dengan ID = " . $data['id_pegawai'];
        getAlert($alertStatus, $alertMessage);




        redirect('admin/pegawai');
    }

    public function delete()
    {
        csrfValidate();
        // POST
        $this->m_pegawai->delete($this->input->post('id_pegawai'));

        // ALERT
        $alertStatus  = "failed";
        $alertMessage = "Menghapus data pegawai : " . $this->input->post('id_pegawai');
        getAlert($alertStatus, $alertMessage);

        redirect('admin/pegawai');
    }
}
