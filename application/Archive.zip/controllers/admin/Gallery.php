<?php
defined('BASEPATH') or exit('No direct script access allowed');
class gallery extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->library('upload');
        if (!$this->session->userdata('user_id')) {
            // ALERT
            $alertStatus  = 'failed';
            $alertMessage = 'Anda tidak memiliki Hak Akses atau Session anda sudah habis';
            getAlert($alertStatus, $alertMessage);
            redirect('admin/dashboard');
        }
    }


    public function index()
    {
        $url = "https://upbuhaluoleo.test-web.my.id/api/getAccessToken?client_id=dr1v3-up6u&client_secret=98fpj-jpkLs-88G5f-9Wq1r";
        $get_url = file_get_contents($url);
        $token =  json_decode($get_url);
        if (!empty($token)) {
            $opts = [
                "http" => [
                    "method" => "GET",
                    "header" => "Access-Token: " . $token->access_token
                ]
            ];
            $context = stream_context_create($opts);
            //DATA
            $data['setting'] = getSetting();
            $data['title'] = 'file';
            if ($this->session->userdata('user_group') == 1 or $this->session->userdata('user_group') == 2) {
                $url = "https://upbuhaluoleo.test-web.my.id/api/get_gallery";
            } else {
                $url = "https://upbuhaluoleo.test-web.my.id/api/get_gallery_pegawai?nip=" . $this->session->userdata('user_nip');
            }

            $get_url = file_get_contents($url, false, $context);
            $data['gallery'] = json_decode($get_url);
            // echo '<pre>';
            // print_r(($data['gallery']));
            // echo '</pre>';
            // die;
            // TEMPLATE
            $view = "_backend/gallery";
            $viewCategory = "all";
            renderTemplate($data, $view, $viewCategory);
        }
    }

    public function pegawai()
    {
        $url = "https://upbuhaluoleo.test-web.my.id/api/getAccessToken?client_id=dr1v3-up6u&client_secret=98fpj-jpkLs-88G5f-9Wq1r";
        $get_url = file_get_contents($url);
        $token =  json_decode($get_url);
        if (!empty($token)) {
            $opts = [
                "http" => [
                    "method" => "GET",
                    "header" => "Access-Token: " . $token->access_token
                ]
            ];
            $context = stream_context_create($opts);
            //DATA
            $data['setting'] = getSetting();
            $data['title'] = 'file';

            $url = "https://upbuhaluoleo.test-web.my.id/api/get_gallery_pegawai?nip=" . $this->uri->segment(4);

            $get_url = file_get_contents($url, false, $context);
            $data['gallery'] = json_decode($get_url);
            // echo '<pre>';
            // print_r(($data['gallery']));
            // echo '</pre>';
            // die;
            // TEMPLATE
            $view = "_backend/gallery_pegawai";
            $viewCategory = "all";
            renderTemplate($data, $view, $viewCategory);
        }
    }

    public function create()
    {
        csrfValidate();
        // if ($_FILES['foto_gallery']['name'] != "") {
        //     $filename_1              = "gallery-" . date('YmdHis');
        //     $config['upload_path']   = "./upload/gallery/";
        //     $config['allowed_types'] = "jpg|png|jpeg";
        //     $config['overwrite']     = "true";
        //     $config['max_size']      = "0";
        //     $config['max_width']     = "10000";
        //     $config['max_height']    = "10000";
        //     $config['file_name']     = '' . $filename_1;
        //     $this->upload->initialize($config);
        //     if (!$this->upload->do_upload('foto_gallery')) {

        //         // ALERT
        //         $alertStatus  = "failed";
        //         $alertMessage = $this->upload->display_errors();
        //         getAlert($alertStatus, $alertMessage);
        //     } else {
        //         $dat  = $this->upload->data();
        //         $data['foto_gallery']      = $dat['file_name'];
        //     }
        // } else {
        //     $data['foto_gallery']      = '';
        // }
        $data['id_gallery']   = $this->input->post('id_gallery');
        $data['nama_gallery'] = $this->input->post('nama_gallery');
        $this->m_gallery->create($data);

        // ALERT
        $alertStatus  = "success";
        $alertMessage = "Berhasil menambah data gallery dengan name = " . $data['nama_gallery'];
        getAlert($alertStatus, $alertMessage);


        redirect('admin/gallery');
    }


    public function update()
    {
        csrfValidate();
        // if ($_FILES['foto_gallery']['name'] != "") {
        //     $filename_1              = "gallery-" . date('YmdHis');
        //     $config['upload_path']   = "./upload/gallery/";
        //     $config['allowed_types'] = "jpg|png|jpeg";
        //     $config['overwrite']     = "true";
        //     $config['max_size']      = "0";
        //     $config['max_width']     = "10000";
        //     $config['max_height']    = "10000";
        //     $config['file_name']     = '' . $filename_1;
        //     $this->upload->initialize($config);
        //     if (!$this->upload->do_upload('foto_gallery')) {

        //         // ALERT
        //         $alertStatus  = "failed";
        //         $alertMessage = $this->upload->display_errors();
        //         getAlert($alertStatus, $alertMessage);
        //     } else {
        //         $dat  = $this->upload->data();
        //         $data['foto_gallery']      = $dat['file_name'];
        //     }
        // }

        // POST
        $data['id_gallery'] = $this->input->post('id_gallery');
        $data['nama_gallery'] = $this->input->post('nama_gallery');
        $this->m_gallery->update($data);

        // ALERT
        $alertStatus  = "success";
        $alertMessage = "Berhasil mengubah data gallery dengan ID = " . $data['id_gallery'];
        getAlert($alertStatus, $alertMessage);




        redirect('admin/gallery');
    }

    public function delete()
    {
        csrfValidate();
        // POST
        $this->m_gallery->delete($this->input->post('id_gallery'));

        // ALERT
        $alertStatus  = "failed";
        $alertMessage = "Menghapus data gallery : " . $this->input->post('id_gallery');
        getAlert($alertStatus, $alertMessage);

        redirect('admin/gallery');
    }
}
